module.exports = function(config) {
  config.set({
    
        
    files: [
   
    'test/*.js'],
    
  });
}
