describe("Compare",function(){
	
it("compare a given number is lesser than 100", function () {
    expect(75).toBeLessThan(100);
});
})
